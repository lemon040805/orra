import json
import boto3
from datetime import datetime

bedrock = boto3.client('bedrock-runtime')

def handler(event, context):
    try:
        body = json.loads(event['body'])
        target_language = body['targetLanguage']
        native_language = body['nativeLanguage']
        level = body['level']
        question_count = body.get('questionCount', 10)
        
        # Generate quiz using Bedrock
        quiz = generate_bedrock_quiz(target_language, native_language, level, question_count)
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'questions': quiz,
                'level': level,
                'generatedAt': datetime.utcnow().isoformat(),
                'method': 'aws_bedrock'
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }

def generate_bedrock_quiz(target_language, native_language, level, question_count):
    prompt = f"""Generate exactly {question_count} multiple choice questions to assess {level} level {target_language} proficiency for a {native_language} speaker.

Requirements:
- Each question must have exactly 4 options
- Include "I don't know" as the 4th option for every question
- Questions should test vocabulary, grammar, and practical usage
- Difficulty appropriate for {level} level

Return ONLY a JSON array with this exact format:
[
  {{
    "question": "Question text here",
    "options": ["Correct answer", "Wrong answer 1", "Wrong answer 2", "I don't know"],
    "correct": 0
  }}
]

Generate {question_count} questions for {level} {target_language}:"""

    response = bedrock.invoke_model(
        modelId='anthropic.claude-3-haiku-20240307-v1:0',
        body=json.dumps({
            'anthropic_version': 'bedrock-2023-05-31',
            'max_tokens': 3000,
            'messages': [{'role': 'user', 'content': prompt}]
        })
    )
    
    result = json.loads(response['body'].read())
    quiz_content = result['content'][0]['text']
    
    # Clean JSON response
    quiz_content = quiz_content.strip()
    if quiz_content.startswith('```json'):
        quiz_content = quiz_content[7:]
    if quiz_content.endswith('```'):
        quiz_content = quiz_content[:-3]
    quiz_content = quiz_content.strip()
    
    quiz_data = json.loads(quiz_content)
    
    # Ensure "I don't know" option
    for question in quiz_data:
        if len(question['options']) < 4:
            question['options'].append("I don't know")
        elif question['options'][3] != "I don't know":
            question['options'][3] = "I don't know"
    
    return quiz_data[:question_count]
